package phase5_1_project;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

import java.io.File;

public class SelAuto {

    public static void main(String[] args) {
        // Set the path to the ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "U:\\seleniumjars\\chromedriver.exe");

        // Initialize ChromeDriver
        WebDriver driver = new ChromeDriver();

        try {
            // Step 1: Registration
            driver.get("http://127.0.0.1:5500/register.html?"); // Replace with the registration page URL

            // Find and fill in the registration form fields
            driver.findElement(By.id("username")).sendKeys("bhanu priya");
            driver.findElement(By.id("email")).sendKeys("bp@gmail.com");
            driver.findElement(By.id("password")).sendKeys("bhanu");
             driver.findElement(By.id("confirm_password")).sendKeys("bhanu");
            Thread.sleep(2000);
            // Submit the registration form
            driver.findElement(By.id("register_button")).click(); // Replace with the registration button element ID

            // Step 2: Login
            driver.get("http://127.0.0.1:5500/loginform.html"); // Replace with the login page URL

            // Find and fill in the login form fields
            driver.findElement(By.id("login_username")).sendKeys("bhanu priya");
            driver.findElement(By.id("login_password")).sendKeys("bhanu");
            Thread.sleep(2000);
            // Submit the login form
            driver.findElement(By.id("login_button")).click(); // Replace with the login button element ID

            // Wait for a few seconds (optional)
            Thread.sleep(3000);

            // Take a screenshot on successful automation
            takeScreenshot(driver, "automation_screenshot.png");

            // You can add more actions after login if needed

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser after the script is done
            driver.quit();
        }
    }

    // Helper method to take a screenshot
    private static void takeScreenshot(WebDriver driver, String fileName) {
        try {
            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileHandler.copy(screenshot, new File("U:\\"+fileName+".png"));
            System.out.println("Screenshot saved: " + "U:\\"+fileName+".png");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

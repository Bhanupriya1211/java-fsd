package arithmeticcalculator;

public interface Operate {
	 Double getResult(Double... numbers);

}

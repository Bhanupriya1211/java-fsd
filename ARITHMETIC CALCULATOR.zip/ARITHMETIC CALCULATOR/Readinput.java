package arithmeticcalculator;
import java.util.*;
public class Readinput {


	public static String read() {



	Scanner in = new Scanner(System.in);



	System.out.println("Enter the value ");



	String input = in.nextLine();



	in.close();

	return input;


	}

}

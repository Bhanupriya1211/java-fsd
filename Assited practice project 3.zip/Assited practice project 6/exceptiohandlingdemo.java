package phase1;

public class exceptiohandlingdemo {
    public static void main(String[] args) {
        try {
            // Code that may throw an exception
            int[] numbers = {1, 2, 3};
            System.out.println("Element at index 3: " + numbers[3]);
        } catch (ArrayIndexOutOfBoundsException e) {
            // Exception handler for ArrayIndexOutOfBoundsException
            System.out.println("Exception caught: " + e.getMessage());
        } finally {
            // Code that always executes, regardless of whether an exception occurred or not
            System.out.println("Finally block executed");
        }

        try {
            // Code that may throw an exception
            int result = divide(10, 0);
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            // Exception handler for ArithmeticException
            System.out.println("Exception caught: " + e.getMessage());
        } finally {
            // Code that always executes, regardless of whether an exception occurred or not
            System.out.println("Finally block executed");
        }
    }

    public static int divide(int numerator, int denominator) {
        return numerator / denominator;
}



}

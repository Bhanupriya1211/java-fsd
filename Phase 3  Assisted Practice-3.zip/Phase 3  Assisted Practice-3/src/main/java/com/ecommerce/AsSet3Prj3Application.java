package com.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AsSet3Prj3Application {

	public static void main(String[] args) {
		SpringApplication.run(AsSet3Prj3Application.class, args);
	}

}

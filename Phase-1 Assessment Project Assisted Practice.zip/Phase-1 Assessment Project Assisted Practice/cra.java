package assessment;


import java.util.*;

//CAMERA CLASS

class Camera {
    private int cameraId;
    private String brand;
    private String model;
    private double perDayPrice;
    private boolean rented;
    
    //CONSTRUCTOR
    
    public Camera(int cameraId, String brand, String model, double perDayPrice) {
        this.cameraId = cameraId;
        this.brand = brand;
        this.model = model;
        this.perDayPrice = perDayPrice;
        this.rented = false;
    }
    
    //GETTERS AND SETTERS
    
    public int getCameraId() {
        return cameraId;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getPerDayPrice() {
        return perDayPrice;
    }

    public boolean isRented() {
        return rented;
    }

    public void setRented(boolean rented) {
        this.rented = rented;
    }

    public String getStatus() {
        return rented ? "RENTED" : "AVAILABLE";
    }

    public void setStatus(String status) {
        this.rented = status.equals("RENTED");
    }
}

// CLASS CAMERARENTAL APP

class CameraRentalApp {
    private List<Camera> cameraList;
    private int cameraId;
    private Scanner scanner;
    private double walletBalance;
    
  //CONSTRUCTOR
    
    public CameraRentalApp() {
        cameraList = new ArrayList<>();
        cameraId = 1;
        scanner = new Scanner(System.in);
        walletBalance = 1000;

        // Insert cameras to the cameraList
        insertInitialCameras();
    }

    // Method to insert initial cameras
    private void insertInitialCameras() {


        // Add cameras to the cameraList
        cameraList.add(new Camera(cameraId++, "Canon", "5050", 250.00));
        cameraList.add(new Camera(cameraId++, "Nikon", "D750", 300.00));
        cameraList.add(new Camera(cameraId++, "Sony", "A7 III", 3500.0));
        cameraList.add(new Camera(cameraId++, "Some", "dxc", 5000.0));
        cameraList.add(new Camera(cameraId++, "Sony", "HD214", 500.0));
        cameraList.add(new Camera(cameraId++, "Canon", "XLR", 500.0));
        cameraList.add(new Camera(cameraId++, "Fujitsu", "J5", 500.0));
        cameraList.add(new Camera(cameraId++, "Sony", "HD226", 500.0));
        cameraList.add(new Camera(cameraId++, "Samsung", "DS246", 500.0));
        cameraList.add(new Camera(cameraId++, "LG", "L123", 500.0));
        cameraList.add(new Camera(cameraId++, "Canon", "XPL", 1500.0));
        cameraList.add(new Camera(cameraId++, "Chroma", "CT", 500.0));

    }
    //DISPLAY MENU 
    
    public void displayMenu() {
        System.out.println("+--------------------------------------+");
        System.out.println("|     WELCOME TO CAMERA RENTAL APP      |");
        System.out.println("+--------------------------------------+");
        System.out.println("\nPLEASE LOGIN TO CONTINUE.\n");
        System.out.print("USERNAME: ");
        String username = scanner.nextLine();
        System.out.print("PASSWORD: ");
        String password = scanner.nextLine();

        // Perform login authentication (validation logic omitted for simplicity)
        boolean loggedIn = authenticateUser(username, password);

        if (loggedIn) {
            boolean exit = false;

            while (!exit) {
                System.out.println("\n+-----------------------------------+");
                System.out.println("|               MAIN MENU           |");
                System.out.println("+-----------------------------------+");
                System.out.println("1. MY CAMERA");
                System.out.println("2. RENT A CAMERA");
                System.out.println("3. VIEW ALL CAMERAS");
                System.out.println("4. MY WALLET");
                System.out.println("5. EXIT\n");
                System.out.println("+-----------------------------------+");
                System.out.print("Enter your choice: ");
                
                int choice = Integer.parseInt(scanner.nextLine());
                System.out.println();

                //SWITCH CASE FOR MAIN MENU
                
                switch (choice) {
                    case 1:
                        handleMyCamera();
                        break;
                    case 2:
                        handleRentCamera();
                        break;
                    case 3:
                        handleViewAllCameras();
                        break;
                    case 4:
                        handleMyWallet();
                        break;
                    case 5:
                        exit = true;
                        System.out.println("Thank you for using the Camera Rental App. Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                        break;
                }
            }
        } else {
            System.out.println("Invalid login credentials. Exiting...");
        }
    }

    //EXISTING USER LIST
    
    private boolean authenticateUser(String username, String password) {
        // Define a map to store user credentials
        Map<String, String> userCredentials = new HashMap<>();
        userCredentials.put("Bhanupriya", "bp@12");
        userCredentials.put("Pranavi", "pk@12");
        userCredentials.put("Prakash", "op@12");

        // Check if the provided username exists in the map
        if (userCredentials.containsKey(username)) {
            // Compare the provided password with the stored password for the given username
            String storedPassword = userCredentials.get(username);
            return password.equals(storedPassword);
        }

        // Username not found in the map
        return false;
    }


    private void handleMyCamera() {
        boolean exit = false;
        
      //SWITCH CASE FOR  SUB MENU
        
        while (!exit) {
            System.out.println("\n+-----------------------------------+");
            System.out.println("|            MY CAMERA MENU         |");
            System.out.println("+-----------------------------------+");
            System.out.println("1. ADD");
            System.out.println("2. REMOVE");
            System.out.println("3. VIEW MY CAMERAS");
            System.out.println("4. GO TO PREVIOUS MENU\n");
            System.out.println("+-----------------------------------+");
            System.out.print("Enter your choice: ");
            int choice = Integer.parseInt(scanner.nextLine());
            System.out.println();

            switch (choice) {
                case 1:
                    handleAddCamera();
                    break;
                case 2:
                    handleRemoveCamera();
                    break;
                case 3:
                    handleViewMyCameras();
                    break;
                case 4:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    //ADD CAMERA
    
    private void handleAddCamera() {
        System.out.print("ENTER THE CAMERA BRAND: ");
        String brand = scanner.nextLine();
        System.out.print("ENTER THE MODEL: ");
        String model = scanner.nextLine();
        System.out.print("ENTER THE PER DAY PRICE (INR): ");
        int perDayPrice = Integer.parseInt(scanner.nextLine());
        Camera camera = new Camera(cameraId, brand, model, perDayPrice);
        cameraList.add(camera);
        cameraId++;
        System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST.");
    }

    //REMOVE CAMERA
    
    private void handleRemoveCamera() {
    	    if (cameraList.isEmpty()) {
    	        System.out.println("No cameras available to remove.");
    	    } else {
    	        System.out.println("+-----------------------------------+");
    	        System.out.println("|     AVAILABLE CAMERAS TO REMOVE    |");
    	        System.out.println("+-----------------------------------+");
    	        System.out.println("=============================================================================");
    	        System.out.println("CAMERA ID\tBRAND\t\tMODEL\t\tPRICE\t\tSTATUS");
    	        System.out.println("=============================================================================");
    	        
    	        //DISPLAYING AVAILABLE CAMERA TO BE REMOVED
    	        
    	        for (Camera camera : cameraList) {
    	            if (camera.getStatus().equals("AVAILABLE")) {
    	            	 System.out.printf("%d\t\t%s\t\t%s\t\t%.2f\t\t%s%n", camera.getCameraId(), camera.getBrand(),
    	                         camera.getModel(), camera.getPerDayPrice(), camera.getStatus());
    	            }
    	        }
    	        System.out.println("=============================================================================");
    	        System.out.print("Enter the camera ID you want to remove: ");
    	        int cameraId = Integer.parseInt(scanner.nextLine());
    	        boolean removed = false;
    	        
               //REMOVE CAMERA FROM THE LIST 
    	        
    	        for (Camera camera : cameraList) {
    	            if (camera.getCameraId() == cameraId && camera.getStatus().equals("AVAILABLE")) {
    	                removed = cameraList.remove(camera);
    	                break;
    	            }
    	        }

    	        if (removed) {
    	            System.out.println("Camera removed successfully.");
    	        } else {
    	            System.out.println("Camera not found or already rented.");
    	    }
    	}

    }
    
    //HANDLE MY CAMERA
    
    private void handleViewMyCameras() {
        List<Camera> rentedCameras = new ArrayList<>();

        for (Camera camera : cameraList) {
            if (camera.isRented()) {
                rentedCameras.add(camera);
            }
        }

        if (rentedCameras.isEmpty()) {
            System.out.println("You have no rented cameras.");
        } else {
            System.out.println("+-----------------------------------+");
            System.out.println("|          MY RENTED CAMERAS        |");
            System.out.println("+-----------------------------------+");
            System.out.println("=============================================================================");
            System.out.println("CAMERA ID\tBRAND\t\tMODEL\t\tPRICE\t\tSTATUS");
            System.out.println("=============================================================================");
            for (Camera camera : rentedCameras) {
           	 System.out.printf("%d\t\t%s\t\t%s\t\t%.2f\t\t%s%n", camera.getCameraId(), camera.getBrand(),
                     camera.getModel(), camera.getPerDayPrice(), camera.getStatus());
            }
            System.out.println("=============================================================================");
        }
    }

    
   //RENT A CAMERA
    
    private void handleRentCamera() {
        System.out.println("+-----------------------------------+");
        System.out.println("|        AVAILABLE CAMERAS          |");
        System.out.println("+-----------------------------------+");
        System.out.println("=============================================================================");
        System.out.println("CAMERA ID\tBRAND\t\tMODEL\t\tPRICE\t\tSTATUS");
        System.out.println("=============================================================================");

        for (Camera camera : cameraList) {
            if (camera.getStatus().equals("AVAILABLE")) {
            	System.out.printf("%d\t\t%s\t\t%s\t\t%.2f\t\t%s%n", camera.getCameraId(), camera.getBrand(),
                        camera.getModel(), camera.getPerDayPrice(), camera.getStatus());
            }
        }
        System.out.println("=============================================================================");

        System.out.print("Enter the CAMERA ID of the camera you want to rent: ");
        int cameraId = Integer.parseInt(scanner.nextLine());
        Camera rentedCamera = null;

        for (Camera camera : cameraList) {
            if (camera.getCameraId() == cameraId) {
                rentedCamera = camera;
                break;
            }
        }
        
          //CEHCKING WALLET BALANCE
        
        if (rentedCamera != null && rentedCamera.getStatus().equals("AVAILABLE")) {
            if (walletBalance >= rentedCamera.getPerDayPrice()) {
                walletBalance -= rentedCamera.getPerDayPrice();
                rentedCamera.setStatus("RENTED");
                System.out.println("Camera rented successfully.");
            }
            
            else {
                System.out.println("Insufficient funds in your wallet. Cannot rent the camera.");
            }
        } else {
            System.out.println("Camera not found or already rented.");
        }
    }
    
  //ALL CAMERAS
    
    private void handleViewAllCameras() {
        if (cameraList.isEmpty()) {
            System.out.println("No cameras available.");
        } else {
            System.out.println("+-----------------------------------+");
            System.out.println("|           ALL CAMERAS             |");
            System.out.println("+-----------------------------------+");
            System.out.println("=============================================================================");
            System.out.println("CAMERA ID\tBRAND\t\tMODEL\t\tPRICE\t\tSTATUS");
            System.out.println("=============================================================================");

            for (Camera camera : cameraList) {
              
            	 System.out.printf("%d\t\t%s\t\t%s\t\t%.2f\t\t%s%n", camera.getCameraId(), camera.getBrand(),
                         camera.getModel(), camera.getPerDayPrice(), camera.getStatus());
            }
            System.out.println("=============================================================================");
        }
    }

    private void handleMyWallet() {
        System.out.println("YOUR CURRENT WALLET BALANCE IS INR. " + walletBalance);
        System.out.println("DO YOU WANT TO DEPOSIT MORE AMOUNT TO YOUR WALLET?");
        System.out.println("1. YES");
        System.out.println("2. NO");
        System.out.print("Enter your choice: ");
        int choice = Integer.parseInt(scanner.nextLine());

        if (choice == 1) {
            System.out.print("ENTER THE AMOUNT (INR): ");
            double depositAmount = Double.parseDouble(scanner.nextLine());
            walletBalance += depositAmount;
            System.out.println(
                    "YOUR WALLET BALANCE UPDATED SUCCESSFULLY. CURRENT WALLET BALANCE - INR. " + walletBalance);
        } else if (choice == 2) {
            System.out.println("No amount deposited. Current wallet balance remains unchanged.");
        } else {
            System.out.println("Invalid choice.");
        }
    }
}

public class cra {
    public static void main(String[] args) {
        CameraRentalApp app = new CameraRentalApp();
        app.displayMenu();
    }
}

package SpringAp1.AP1;
public class MyBean {
    public void sayHello() {
        System.out.println("Hello, Spring Framework!");
    }
}



package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AsSet2Prj4Application {

	public static void main(String[] args) {
		SpringApplication.run(AsSet2Prj4Application.class, args);
	}

}

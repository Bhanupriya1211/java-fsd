package loading_webpage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;


public class SelAuto {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "U:/seleniumjars/chromedriver.exe");
        WebDriver wd= new ChromeDriver();
        wd.manage().window().maximize();
        wd.get("https://www.amazon.in/");
        wd.findElement(By.linkText("Start here.")).click();
        wd.findElement(By.id("ap_customer_name")).sendKeys("bhanu priya");
        wd.findElement(By.id("ap_phone_number")).sendKeys("99999999");
        wd.findElement(By.id("ap_email")).sendKeys("bp@gmail.com");
        wd.findElement(By.name("password")).sendKeys("kkkkkk");
        wd.findElement(By.id("continue")).click();

        
        try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        wd.close();
        
    }
}

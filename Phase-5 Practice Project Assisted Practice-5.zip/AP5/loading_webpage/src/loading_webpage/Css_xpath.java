package loading_webpage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Css_xpath {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "U:\\seleniumjars\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.amazon.in/");

                // Find the search box and enter "Samsung mobiles" as the search query
                WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
                searchBox.sendKeys("Samsung mobiles");

                // Find the search button and click on it
                WebElement searchButton = driver.findElement(By.id("nav-search-submit-button"));
                searchButton.click();

                // Wait for the search results to load (You might need to use explicit waits here)

                // Find all elements representing the search results
                List<WebElement> searchResults = driver.findElements(By.cssSelector(".s-result-list .s-result-item"));

                // Loop through each search result and extract information
                for (WebElement searchResult : searchResults) {
                    // Example: Extract the product title
                    WebElement titleElement = searchResult.findElement(By.cssSelector(".a-size-medium"));
                    String title = titleElement.getText();
                    System.out.println("Product Title: " + title);

                    // Example: Extract the product price
                    WebElement priceElement = searchResult.findElement(By.cssSelector(".a-price .a-offscreen"));
                    String price = priceElement.getText();
                    System.out.println("Price: " + price);

                    // Example: Extract the product URL
                    WebElement urlElement = searchResult.findElement(By.cssSelector(".a-link-normal.a-text-normal"));
                    String url = urlElement.getAttribute("href");
                    System.out.println("URL: " + url);

                    // Add more code to extract other relevant information if needed
                    System.out.println("--------------------------");
                }

                // Close the browser
                driver.quit();

    }
}

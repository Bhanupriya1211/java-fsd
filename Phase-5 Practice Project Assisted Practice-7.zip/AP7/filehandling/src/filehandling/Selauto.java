package filehandling;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Selauto {
    public static void main(String[] args) throws InterruptedException, IOException {
        // Register the Chrome driver
        System.setProperty("webdriver.chrome.driver", "U:\\seleniumjars\\chromedriver.exe");

        // Create an object for the driver - an object for the web browser
        WebDriver wd = new ChromeDriver(); // 'wd' is the controller object for the web browser

        // Maximize the screen
        wd.manage().window().maximize();
        wd.manage().timeouts().implicitlyWait(2000, TimeUnit.MILLISECONDS);

        // Web URL
        wd.get("https://www.ilovepdf.com/pdf_to_word");

        // Click the "pick files" button to upload a file
        wd.findElement(By.id("pickfiles")).click();

        // Provide the correct path for the AutoIt script to upload a file.
        // Note: You need to specify the full path of the AutoIt script with the .exe extension.
        Runtime.getRuntime().exec("U:\\fileupload.exe"); // Replace "U:\\fileupload.au3" with the correct path

        // Click the "processTask" button to start the task
        wd.findElement(By.xpath("//*[@id='processTask']")).click();
    }
}

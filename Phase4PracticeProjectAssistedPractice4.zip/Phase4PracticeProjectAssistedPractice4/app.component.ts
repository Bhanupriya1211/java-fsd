import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public name="Bhanu";
  public isDisabled=false;
  public cb=true;
  public x="design me";
  public highlightColor="green";
  public highlight={
    color:"white",
    backgroundColor:"yellow"
  }
  public d=true;
  greet(){
    console.log("welcome to event binding");
  }

  title = 'binding';
}

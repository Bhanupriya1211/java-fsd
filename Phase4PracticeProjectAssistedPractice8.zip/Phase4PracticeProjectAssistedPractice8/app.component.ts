import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public name="Hey Bhanu! welcome..";
  public category={
    gender:"female",
    age:23
  };
  public date=new Date();
  title = 'binding';
}

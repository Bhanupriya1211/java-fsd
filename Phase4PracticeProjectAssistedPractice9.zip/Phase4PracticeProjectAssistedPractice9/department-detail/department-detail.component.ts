import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';

@Component({
  selector: 'app-department-detail',
  template: `
    <p>
      The ID is {{ id }}
    </p>
    <a (click)="goPrevious()">previous</a>
    <a (click)="goNext()">next</a>
    <button (click)="goBack()"> back</button>
  `,
  styles: []
})
export class DepartmentDetailComponent implements OnInit {
  public id!: number;

  constructor(private route: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {
    this.id = Number(this.route.snapshot.paramMap.get('id'));
    this.route.paramMap.subscribe((params: ParamMap) => {
      const idParam = params.get('id');
      this.id = idParam !== null ? parseInt(idParam) : 0; // Use a default value if idParam is null
    });
  }

  goPrevious() {
    let previousId = this.id - 1;
    this.router.navigate(['/departments', previousId]);
  }

  goNext() {
    let nextId = this.id + 1;
    this.router.navigate(['/departments', nextId]);
  }
  goBack(){
    
  }
}

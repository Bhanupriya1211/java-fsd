import { Component,OnInit} from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-departmentlist',
  template: `
    <ul (click)="onselect(d)" *ngFor="let d of departments">
      <li> {{d.id}}-{{d.name}} </li>
      <ul>
 
  `,
  styles: [
  ]
})
export class DepartmentlistComponent implements OnInit{
departments=[
  {"id":1,"name":"angular"},
  {"id":2,"name":"node"},
  {"id":3,"name":"mongodb"},
  {"id":4,"name":"ruby"},
  {"id":5,"name":"bootstrap"},

];
constructor (private router: Router){}
ngOnInit(): void {
  
}
onselect(d:any){
  this.router.navigate(['/departments',d.id]);
}
}

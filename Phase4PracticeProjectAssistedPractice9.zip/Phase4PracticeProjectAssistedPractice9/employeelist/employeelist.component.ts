import { Component } from '@angular/core';

@Component({
  selector: 'app-employeelist',
  template: `
    <p>
      employeelist works!
    </p>
  `,
  styles: [
  ]
})
export class EmployeelistComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-page-not-found',
  template: `
    <p>
      page-not-found works!
    </p>
  `,
  styles: [
  ]
})
export class PageNotFoundComponent {

}

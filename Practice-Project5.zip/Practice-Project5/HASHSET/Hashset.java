package yt;
import java.util.*;
public class Hashset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<String> hs=new HashSet<String>();
		hs.add("bhanu");
		hs.add("priya");
		hs.add("chintapulusu");
		System.out.print(hs);
		System.out.println(hs.contains("bhanu"));
	}

}

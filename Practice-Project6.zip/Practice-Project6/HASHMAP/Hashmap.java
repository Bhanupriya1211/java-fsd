package PhaseOne;
import java.util.*;
public class Hashmap {

	

	

	    public static void main(String[] args) {
	        // Create a new HashMap instance with String keys and Integer values
	        Map<String, Integer> hm = new HashMap<String, Integer>();
	        
	        // Add some key-value pairs to the HashMap
	        hm.put("a", 1);
	        hm.put("b", 2);
	        hm.put("c", 3);
	        
	        // Print the contents of the HashMap
	        System.out.println(hm);
	    }

	}


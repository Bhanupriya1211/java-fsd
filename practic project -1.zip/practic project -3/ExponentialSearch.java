package datastructures;
import java.util.Arrays;
import java.util.Scanner;
public class ExponentialSearch {
	

	    public static int exponentialSearch(int[] arr, int target) {
	        int size = arr.length;

	        if (arr[0] == target) {
	            return 0; // Return the index if the target is found at the beginning
	        }

	        int i = 1;
	        while (i < size && arr[i] <= target) {
	            i *= 2;
	        }

	        int left = i / 2;
	        int right = Math.min(i, size - 1);

	        return binarySearch(arr, target, left, right);
	    }

	    public static int binarySearch(int[] arr, int target, int left, int right) {
	        while (left <= right) {
	            int mid = left + (right - left) / 2;

	            if (arr[mid] == target) {
	                return mid; // Return the index if the target is found
	            }

	            if (arr[mid] < target) {
	                left = mid + 1;
	            } else {
	                right = mid - 1;
	            }
	        }

	        return -1; // Return -1 if the target is not found
	    }

	    public static void main(String[] args) {
	        int[] array = {1, 2, 3, 4, 5, 6, 7, 9};
	        Scanner scanner = new Scanner(System.in);

	        System.out.print("Enter the number to search: ");
	        int target = scanner.nextInt();

	        int index = exponentialSearch(array, target);

	        if (index != -1) {
	            System.out.println("Element found at index " + index);
	        } else {
	            System.out.println("Element not found in the array");
	    }
	}


}

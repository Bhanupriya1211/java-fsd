package datastructures;

public class insertionsort {

	    public static void main(String[] args) {
	    	System.out.println("insertion sort");
	        int a[] = {2, 7, 4, 5};
	        int n = a.length;
            System.out.println("before sorting:");
	        for (int i = 0; i < n; i++) {
	            System.out.print(" " + a[i]);
	        }
	        System.out.println();

	        for (int i = 1; i < n; i++) {
	            int key = a[i];
	            int j;

	            for (j = i - 1; j >= 0 && a[j] > key; j--) {
	                a[j + 1] = a[j];
	            }

	            a[j + 1] = key;
	        }
	        System.out.println("after sorting:");
	        for (int i = 0; i < n; i++) {
	            System.out.print(" " + a[i]);
	    }

	}

}
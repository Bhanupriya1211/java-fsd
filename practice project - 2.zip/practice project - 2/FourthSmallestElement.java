package Asp3;
	import java.util.Arrays;
	import java.util.Scanner;

	public class FourthSmallestElement {

	    public static void main(String[] args) {
	        Scanner input = new Scanner(System.in);
	        
	        System.out.print("Enter the number of elements in the list: ");
	        int n = input.nextInt();
	        int[] arr = new int[n];
	        
	        System.out.println("Enter the elements of the list:");
	        for(int i=0; i<n; i++) {
	            arr[i] = input.nextInt();
	        }
	        
	        // Sort the array in ascending order
	        Arrays.sort(arr);
	        
	        // Find the fourth smallest element in the sorted array
	        int fourthSmallest = arr[3];
	        
	        System.out.println("The fourth smallest element in the list is: " + fourthSmallest);

	}


}

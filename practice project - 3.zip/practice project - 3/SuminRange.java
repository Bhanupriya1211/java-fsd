package Asp3;
import java.util.Scanner;
public class SuminRange {


	    public static void main(String[] args) {
	        Scanner input = new Scanner(System.in);
	        
	        System.out.print("Enter the number of elements in the array: ");
	        int n = input.nextInt();
	        int[] arr = new int[n];
	        
	        System.out.println("Enter the elements of the array:");
	        for(int i=0; i<n; i++) {
	            arr[i] = input.nextInt();
	        }
	        
	        System.out.print("Enter the value of L (0 <= L <= " + (n-1) + "): ");
	        int L = input.nextInt();
	        
	        System.out.print("Enter the value of R (L <= R <= " + (n-1) + "): ");
	        int R = input.nextInt();
	        
	        // Find the sum of elements in the range of L and R
	        int sum = 0;
	        for(int i=L; i<=R; i++) {
	            sum += arr[i];
	        }
	        
	        System.out.println("The sum of elements in the range of " + L + " and " + R + " is: " + sum);

	}


}

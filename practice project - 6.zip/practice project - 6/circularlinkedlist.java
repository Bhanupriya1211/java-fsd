package Asp3;

public class circularlinkedlist {

	    private ListNode tail;
	    private int size;

	    private static class ListNode {
	        private int data;
	        private ListNode next;

	        public ListNode(int data) {
	            this.data = data;
	        }
	    }

	    public void insert(int value) {
	        ListNode newNode = new ListNode(value);

	        if (tail == null) {
	            tail = newNode;
	            tail.next = tail;
	            size++;
	            return;
	        }

	        ListNode current = tail.next;
	        ListNode previous = tail;

	        while (current != tail && value > current.data) {
	            previous = current;
	            current = current.next;
	        }

	        if (value <= current.data) {
	            newNode.next = current;
	            previous.next = newNode;
	        } else {
	            newNode.next = tail.next;
	            tail.next = newNode;
	            tail = newNode;
	        }

	        size++;
	    }

	    public void display() {
	        if (tail == null) {
	            return;
	        }

	        ListNode current = tail.next;
	        do {
	            System.out.print(current.data + " -> ");
	            current = current.next;
	        } while (current != tail.next);
	        System.out.println("head");
	    }

	    public static void main(String[] args) {
	    	circularlinkedlist list = new circularlinkedlist();

	        list.insert(5);
	        list.insert(10);
	        list.insert(20);
	        list.insert(15);
	        list.insert(25);

	        list.display();
	}


}

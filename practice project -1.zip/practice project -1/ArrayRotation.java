package Asp3;
import java.util.Scanner;
public class ArrayRotation {

	    public static void main(String[] args) {
	        Scanner input = new Scanner(System.in);
	        
	        System.out.print("Enter the number of elements in the array: ");
	        int n = input.nextInt();
	        int[] arr = new int[n];
	        
	        System.out.println("Enter the elements of the array:");
	        for(int i=0; i<n; i++) {
	            arr[i] = input.nextInt();
	        }
	        
	        System.out.println("Original Array: ");
	        for(int i=0; i<n; i++) {
	            System.out.print(arr[i] + " ");
	        }
	        
	        // Perform the right rotation by 5 steps
	        int k = 5;
	        for(int i=0; i<k; i++) {
	            int lastElement = arr[n-1];
	            for(int j=n-1; j>0; j--) {
	                arr[j] = arr[j-1];
	            }
	            arr[0] = lastElement;
	        }
	        
	        System.out.println("\nArray after right rotation by 5 steps: ");
	        for(int i=0; i<n; i++) {
	            System.out.print(arr[i] + " ");
	        }
	    }

}
